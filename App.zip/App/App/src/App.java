public class App {
    public static void main(String[] args) throws Exception {
        texte texte = new texte(1, "C:\\Users\\Juba Loudahi\\OneDrive - UPEC\\BUT1-Info\\S2\\SAE2.02\\App\\App\\src\\sujet1.txt");
        texte.extraire_texte();
    }
}
















